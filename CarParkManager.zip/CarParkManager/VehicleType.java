

public enum VehicleType {
	
	Car, Van, MotorBike

}
