import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class Multithread
{
    
    VehicleType type;
    BambaCarParkManager managerobj = new BambaCarParkManager();
    ObjectCreator creater = new ObjectCreator();
    Queue<VehicleType> q = new LinkedList<>();
    ArrayList<Vehicle> groundFloor = new ArrayList<Vehicle>();
    ArrayList<Vehicle> firstFloor = new ArrayList<Vehicle>();
    ArrayList<Vehicle> SecondFloor = new ArrayList<Vehicle>();
    
    
    public void vehicals() throws InterruptedException{
        Multithread classobj = new Multithread();
    
    System.out.println("Enter total number of vehicals");
    Scanner sc = new Scanner(System.in);
    int vehicalnmbr = sc.nextInt();
    
    for (int a = 0;a<=vehicalnmbr;a++ )
    {


    System.out.println("Enter Vehical Type");
    System.out.println("1. Car");
    System.out.println("2. Van");
    System.out.println("3. MotorBike");
    int x = sc.nextInt();
    VehicleType type = (x == 1)?VehicleType.Car:(x == 2)?
				VehicleType.MotorBike:(x == 3)?
						VehicleType.Van:null;
                        q.add(type);
                        classobj.type = type;
    }

    
    Threads Runnable = new Threads();
    
    Thread NG1 = new Thread(Runnable);
    Thread NG2 = new Thread(Runnable);
    Thread EG1 = new Thread(Runnable);
    Thread EG2 = new Thread(Runnable);
    Thread WG1 = new Thread(Runnable);
    Thread WG2 = new Thread(Runnable);
    Thread SG1 = new Thread(Runnable);
    Thread SG2 = new Thread(Runnable);
    NG1.setPriority(Thread.MAX_PRIORITY);
    NG1.start();
    

    if(NG1.isAlive()){
        NG1.join();
        NG2.start();
    }
    else if(NG2.isAlive()) {
        NG2.join();
        EG1.start();
    }
    else if(EG1.isAlive())
    {
        EG1.join();
        EG2.start();
    }
    else if(EG2.isAlive())
    {
        EG2.join();
        WG1.start();
    }
    else if(WG1.isAlive())
    {
        WG1.join();
        WG2.start();
    }
    else if(WG2.isAlive())
    {
        WG2.join();
        SG1.start();
    }
    else if(SG1.isAlive())
    {
        SG1.join();
        SG2.start();
    }
    
sc.close(); }



}

class Threads implements Runnable
{

    @Override
    public void run() {

        BambaCarParkManager managerobj = new BambaCarParkManager();
        ObjectCreator creater = new ObjectCreator();
        Multithread classobj = new Multithread();
        Vehicle vehicle = creater.createVehicle(classobj.type); 
        
        System.out.println("Thread");
        classobj.q.remove();
        for (VehicleType a : classobj.q)
    {


        if(classobj.groundFloor.size()<80){
        if (VehicleType.Car == a )
        {
            Thread.currentThread().setPriority(Thread.MAX_PRIORITY);
        }
       //vehical is created here 
        managerobj.addVehicle(vehicle);
        }
        else if(classobj.firstFloor.size()<60)
        {
            if (VehicleType.Van== a )
        {
            Thread.currentThread().setPriority(Thread.MAX_PRIORITY);
        }
        managerobj.addVehicle(vehicle);
        }
        else if(classobj.SecondFloor.size()<70)
        {
            if (VehicleType.Van== a || VehicleType.Car == a )
            {
                managerobj.addVehicle(vehicle);
            }
            else
            {
                System.out.println("Sorry no space for Motorbikes on 2nd floor");
            }
        }
        else
        {
            System.out.println("Sorry not enough space for any vehical");
        }

    
    }
        
        
    }
    
}
