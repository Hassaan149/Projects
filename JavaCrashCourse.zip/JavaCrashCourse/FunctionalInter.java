// Single abstract method interface - funtional interface
//lambda expression for functional interface
//marker interface has no method
@FunctionalInterface
interface xyz{
void show();

}

public class FunctionalInter {


    public static void main(String[]args){
        xyz obj = () -> System.out.println("lambda expression");
       
        obj.show();
        

    }
    
}
