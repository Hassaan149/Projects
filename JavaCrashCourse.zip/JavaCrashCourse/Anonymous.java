class orange
{
public void show()
{
    System.out.println("in show");
}

}




public class Anonymous {
    

    public static void main(String[] args) {


        orange obj = new orange()
        {
            public void show()
{
    System.out.println("in sub class");
}

        };// this is anonymous class
        obj.show();
        
    }
}
//this can be done with interfaces as well