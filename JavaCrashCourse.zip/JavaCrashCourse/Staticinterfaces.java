
interface demo2
{
    int num = 0; // can create a variable but final by default
    void method();
    static void show() // can also define static methods in interface
    
    {
        System.out.println("hi");
    }
}

public class Staticinterfaces {

    public static void main(String[]args)
    {
        demo2.show();
    }
    
}
