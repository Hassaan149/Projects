class calculate{

    public int add(int ... z)//this can accept multiple arguments as an array   
    {
        int sum=0;
        for( int a: z)
        {
            sum = sum+a;
        }

return sum;
    }



}






public class VarArgs {
    public static void main(String[] args) {
      //varargs stands for variable length arguments
        calculate obj = new calculate();
        System.out.println(obj.add(4,5,6,7,4,5,6,7,8));

        
    }
    
}
