import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class mapInterface {

    public static  void main(String[] args) 
    {

        Map<String,String> map = new HashMap<>();//HashTable is synchronized
        map.put("name","Hassan");
        map.put("rollno","149");
        map.put("subject","Ai");

       Set<String> keys = map.keySet();
       for(String key: keys)
       {
        System.out.println(map.get(key));
       }




    }
}
