class X
{
    
    public void show()
    {
        System.out.println("in X class");
    }

}

class Y extends X
{   
    
    public void show()
    {   
        super.show();
        System.out.println("in Y class");
    }



}
//super keyword is used to specify same name objects of super class in sub class

// if super and sub class both have same name methods then the sub
// class method will override the super class methodl
public class OverRiding {

    public static void main(String[]args) {

        Y obj = new Y();
        obj.show();
        
    }
    
}
