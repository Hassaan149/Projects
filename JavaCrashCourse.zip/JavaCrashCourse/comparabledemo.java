import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

class Studs implements Comparable<Studs>
{
    int rollno,marks;
    String name;
    public Studs(int rollno,String name,int marks)
    {
        super();
        this.rollno = rollno;
        this.name = name;
        this.marks = marks;


    }

    @Override
    public String toString() {
        return "Studs [marks=" + marks + ", name=" + name + ", rollno=" + rollno + "]";
    }
    public int compareTo(Studs o)
        {
            return marks>o.marks?1:-1;
        }



}

public class comparabledemo {




    public static void main(String[] args) {

        List<Studs> stud = new ArrayList<>();

        stud.add(new Studs(149,"Hassaan",89));
        stud.add(new Studs(49,"Badar",80));
        stud.add(new Studs(62,"Afnan",85));

        Collections.sort(stud);
        for (Studs s:stud)
        {

            System.out.println(s);

        }
        



    }
    
}
