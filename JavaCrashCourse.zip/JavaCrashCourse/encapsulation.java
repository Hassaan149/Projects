class Student
{

    private int rollno;
    private String name;
    //Getters and Setters
    public int getRollno() {
        return rollno;
    }

    public void setRollno(int rollno) {
        this.rollno = rollno;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    // public void setRollno(int r)
    // {

    //     rollno = r;


    // }

    // public int getRollno()
    // {
    //     return rollno;
    // }


    


}



// binding data with methods is called encapsulation

// why we need it?
// Ans:  to make the data manipulation safe, maintaaing a log file


public class encapsulation {

    public static void main(String[] args) 
    {
        

        Student s1 = new Student();
        s1.setRollno(149);
        s1.setName("hassaan");
        System.out.println(s1.getRollno());
        System.out.println(s1.getName());

    }
    
}
