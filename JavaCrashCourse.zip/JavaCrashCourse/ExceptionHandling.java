



public class ExceptionHandling {

    public static void main(String[]args) {
//unchecked, comes at runtime
        try {
            int a[]=new int[5];
            a[6]=4;
           int i = 9/0;
        }
        // multiple exceptions in one catch
        catch(NullPointerException | ArithmeticException | ArrayIndexOutOfBoundsException e)// for math errors
        {
            System.err.println("error"); //err is for red color
        }
       
        finally // executed at any situation
        {
            System.out.println("final block");


        }
// try using last catch block with Exception class instead of specifying
// cuz we dont know what type of exceptions can occur
        
    }
    
}
