class A
{

     public A()
     {
        System.out.println("in A");
     }
     public A(int a)
     {
         System.out.println("in A int");
     }

}
class B extends A
{
 public B()
 {
    System.out.println("in B");
 }

 public B(int a)
     {     
         super(a);// this will call param constructor of super class
         System.out.println("in B int");
     }

}




public class superKeyword {


    public static void main(String[] arg)
    {

        B obj =new B(4); // it called default of super class and parameterized of sub class
       


    }
    
}
