import java.util.ArrayList;
import java.util.List;

public class CollectionNdGenerics {
    public static  void main(String[] args) {
        //List can be of any type

        /*Collection*/List<Integer> values = new ArrayList<>();
        //List has the index number
        //add(index,value)
        values.add(5);
        values.add(10);
        values.add(13);
        values.add(5);
        
        //list supports every thing

        //Collections.sort(List); sorts the list elements in asceneding
        //Collections.reverse(List); reverses the list elements
        
        
        //Collections.sort(values,Comparator object)
        
        
        //collection has no index number;
        // Iterator it = values.iterator();
        // while (it.hasNext())// print unitl iterator has the values
        // {
        //     System.out.println(it.next());
        // }

        for(Integer o:values)
        {
            System.out.println(o);

        }



         

    }
}
