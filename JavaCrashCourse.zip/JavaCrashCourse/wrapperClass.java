public class wrapperClass {

    public static void main(String[] args) {

        Integer i = new Integer(6); //wrapper class, storing value in object
        Float f = new Float(4.3); //wrapper class
        // its depricated since java 9
        int x = i.intValue(); //unwrapping
    }
    
} // primitive variable works faster then wrapper classes
