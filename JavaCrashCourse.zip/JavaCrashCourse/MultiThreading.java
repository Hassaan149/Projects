



// used anonymous class
// labmda expression
// Functional interface (runnable)

// Thread starts a eun method
// runnable starts a run method


public class MultiThreading {
    public static void main(String[] args) throws Exception
    {
        
        
        

        
        
        Thread t1 = new Thread(()->
        {
               for (int k = 0; k <= 5; k++)
       
               {
                   System.out.println("Hello");
                   try {
                       Thread.sleep(500);
                   } catch (InterruptedException e) {
                       
                       e.printStackTrace();
                   }
       
               }
               
           });
      
        Thread t2 = new Thread(()-> {
            for (int k = 0; k <= 5; k++)

        {
            System.out.println("Hi");
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {

                e.printStackTrace();
            }

        }

    });
        
        t1.start();
        Thread.sleep(100);
        t2.start();
        t1.join();
        t2.join(); // main thread will wait until t1 t2 are executed
        // isAlive() is for knowing whether thread is running or not
        System.out.println("Bye");
        System.out.println(t1.getPriority());
        //.setName() for setting name for threads
        //.setPriority is for setting thread priority



    }
    
}
