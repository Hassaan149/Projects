class outer
{
    int a;
    public void show()
    {

    }

   static class inner
    {   
        // member class
        public void display()
        {

            System.out.println("in memberclass");
        }
    }   


}



public  class innerclass // outer$inner.class this will be its file name
{

public static void main(String[] args)
{
    outer obj = new outer();
    obj.show();

    outer.inner obj1 = new outer.inner();
    //static inner class can be called only by the outerclass name
    // appended to it 

    obj1.display();
    // to use inner clas  we have to use outer clas and to creat
    // the object of inner class we have to use the object 
    // of outer class 
    // 


}


}