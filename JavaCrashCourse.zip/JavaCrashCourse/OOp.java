

class cal{  //super class

    public int add(int x, int y)
    {

    return x+y;}
}
class advCal extends cal
{ //sub class, sub class has all the methods of super class
    
    public int sub(int x, int y)
    {

    return x-y;}
    
    
}
class VadVCal extends advCal  //multi level inheritance
{
    public int multi (int x,int y)
    {


    return x*y;}
}


public class OOp {

    public static void main(String[] args)
    {
        VadVCal obj = new VadVCal();
        System.out.println(obj.add(4,6));
        System.out.println(obj.sub(4,6));
        System.out.println(obj.multi(4,7));


    }
    
}