class Employee
{   
    int Eid;
    int salary;
    static String residence;

    static{
        //in this block a static variable can be initialized
        //but only once as this block is run when the class is loaded
        System.out.println("in static block");
        residence = "Pakistan";
    }

    public void show()
    {
       System.out.println(Eid+":"+salary+":"+residence); 
        System.out.println("in constructor");
    }
    


}



public class staticKeyword {

    public static void main(String[] args)
    {
        //!!!! we cant access a non static variable in a static method



        Employee Hassan =new Employee();
        Hassan.Eid = 5;
        Hassan.salary = 1000;
        // Hassan.residence = "UK";

        Employee Ahmad = new Employee();
        Ahmad.Eid = 10;
        Ahmad.salary = 1100;
        // Ahmad.residence = "US";
        // Employee.residence = "US"; //to access static variables we dont need objects

        Hassan.show();
        Ahmad.show();


    }
    // here are the variables are assiciated with a specifc 
    //object, "static" keyword is used if the variable is
    // declared for all the objects, it removes the specific association to 
    // different objects
    
}
