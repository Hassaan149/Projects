// object of abstract class cant be created, but reference can be
// abstract methods can only be in abstract classes


abstract class Human
{
    abstract void run(); //only declared method(abstract)
    

    public void walk()
    {



    }
}

class man extends Human
{

    @Override
    void run() {
        
            System.out.println("In abstract method");
    }// this class must implement all abstract methods of super class that is
     // abstract


}




public class AbstractKeyword {




    public static void main(String[] args) {

            Human obj = new man(); //Cannot instantiate the type abstract
            obj.run();
        
    }
    
}
