
class calc
{
    int num1;
    
    int result;
    // public int perform(int extra, int prod)
    // {
    //     result = (num1+num2 + extra)*prod;
    //     if (result>50)
    //     {
    //         return 1;
    //     }
    //     else
    //     return 0;

    // }
    public calc() 
    {
        //this is the econstructor
        num1 = 10;
        System.out.println("In simple constructor");

    }
    public calc(int x)
    {
       num1 = x;
       //this will be called if the parameter is given
       System.out.println("In parameterized constructor");
        
    }


}





public class constructor{



    public static void main(String[] args )
    {
        calc obj = new calc(); //This round bracket is the constructor being called automatically
        System.out.println(obj.num1);    
    
    }

    // what is a constructor? 
    // Constructor is like a member method, which has a same name as the Class
    // it doesnt return anything, even if its not created in a class its still there
    // thus its called default constructor
    // its used to allocate memeory
    //  creating the object calls teh constructor
    //  same consturtor with different params in same class is called
    // constructor overloading


}