
class counter
{
    int count;
    public synchronized void increment()// synchronized means only 1 thread at a time is allowed to work, non can interfere other
    {

        count++;
    }


}



public class SyncDemo {

    public static void main(String[]args) throws InterruptedException {

        counter c = new counter();
        c.increment();
        Thread t1 = new Thread(new Runnable()
        {

            @Override
            public void run() {
               for (int i=1;i<=1000;i++)
               {
                   c.increment();
               }

            }
            
        });

        Thread t2 = new Thread(new Runnable()
        {

            @Override
            public void run() {
               for (int i=1;i<=1000;i++)
               {
                   c.increment();
               }

            }
            
        });


        

        t2.start();
        t1.start();
        t1.join();
        t2.join();

        System.out.println("Count:"+c.count);
        
        
    }
    
}
