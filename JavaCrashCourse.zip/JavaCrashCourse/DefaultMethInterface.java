

interface demo{

    void meth1();
    // default keyword allows us to define a method in interface
    // method overriding is possible for default method 
    default void show(){
        System.out.println("in show");
    }
}
//we can use super keyword for interfaces having same name methods as well
// interface name.super.methodname
class forinterface implements demo
{

    @Override
    public void meth1() {
        System.out.println("in implemented method");


    }
    
}



public class DefaultMethInterface {
    public static void main(String[]args) {

        demo obj = new forinterface();
        obj.meth1();
        obj.show();
        

    }
    
}
