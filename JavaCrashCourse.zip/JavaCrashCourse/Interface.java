interface writer
{
     void writing();
    

}

class pen implements writer
{
    public void writing()
    {
        System.out.println("Im a pen");
    }

}

class pencil implements writer
{ 
    public void writing()
    {
        System.out.println("Im a pencil");
    }

}
class box 
{
    public void write(writer w)
    {
        w.writing();
    }

}



public class Interface {
    
    public static void main (String[] args) {

            writer r = new pencil();
            writer r1 = new pen();
            box b = new box();
            b.write(r);

        
    }
}

// Interface is a class where we can only have abstract methods
// we can only create reference of interfaces, not objects
// all methods in interfaces are public abstract
// cant define a method in interface