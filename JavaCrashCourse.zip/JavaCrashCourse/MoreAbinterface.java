interface abc{

    void show();
}

class here implements abc
{

    @Override
    public void show() {
        System.out.println("Implemented Method");

    }
    
}


public class MoreAbinterface {


    public static void main(String[] args) {
        
        abc obj = new here();
        obj.show();
        

    }
    
}
