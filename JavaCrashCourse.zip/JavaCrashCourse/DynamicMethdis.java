class alpha
{


    public void show()
    {
        System.out.println("in alpha");
    }


}

class beta extends alpha
{
    
    public void show()
    {
        System.out.println("in beta");
    }

}










public class DynamicMethdis {

    public static void main(String[] args)
    {
        alpha obj = new beta(); //reference of alpha and constructor of beta
            obj.show();  //it will call method of beta
            obj = new alpha();
            obj.show(); // dynamic method dispatch



    }
    
}
