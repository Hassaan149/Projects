class fruit
{
    /*"final"*/ int i = 0; //The final field cannot be changed later on
    //making a class final stops it from being extended
    //making a method as final stops it from being overridden
    public  fruit()
    {
        i=10; 
    }


}


class FinalKeyword{
    
    public static void main(String[] args)
    {

        fruit obj = new fruit();
        System.out.println(obj.i);
    }

// final keywords can be used with methods, class, variables
}