import java.util.HashSet;
import java.util.Set;

public class SetInterface {
    public static  void main(String[] args) 
    {
        Set<Integer> values = new HashSet<Integer>();//TreeSet will return the valsues in ascending order
        values.add(7);
        values.add(8);
        values.add(3);

        for (int k : values)
        {

            System.out.println(k);
        }



    }
    
}
