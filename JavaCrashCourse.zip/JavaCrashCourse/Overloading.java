class casio{
    public void add(int x, int y)
    {
    System.out.println(x+y);
    }
    public void add(int x, int y, int z)
    {
    System.out.println(x+y*z);
    }
}



public class Overloading {

    public static void main(String[] args)
    {

        casio obj = new casio();
        obj.add(4,7);
        obj.add(4,2,2);
    }

    
    
}

// same name multiple methods in a same class with 
// different params are called to have fulfilled
// the concept of method overloading 
