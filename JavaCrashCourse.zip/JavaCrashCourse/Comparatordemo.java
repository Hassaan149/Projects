import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Comparatordemo {
    
    public static  void main(String[] args) 
    {


        List<Integer> values = new ArrayList<Integer>();
        values.add(38);
        values.add(35);
        values.add(87);

        Comparator<Integer> c = new Comparator<>()
        {
            public int compare(Integer i, Integer j)
            {
                // if(i%10>j%10)
                // return 1;
                // else
                return i%10>j%10?1:-1; //ternary operations
            }
        };

        // ternary operators "?" for if true, ":" for else,

        Collections.sort(values, c);
        for (Integer o: values)
        {
            System.out.println(o);
        }




    }

}
