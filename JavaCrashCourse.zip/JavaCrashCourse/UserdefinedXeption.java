public class UserdefinedXeption {
    
    public static void main(String[]args) 
    {
        int i,j;
        i=5;
        j=7;
        try 
        {
            int k= i/j;

        System.out.println(k);
        if (k==0)
            throw new Exception();

            }

        catch (Exception e)
        {
            System.out.println("Error");
        }
    }
}
