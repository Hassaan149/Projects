public class Arrays {


    public static void main(String[] args)
    {
        //   int nums[] = new int[4];
        
        //   int nums[] = {3,5,1,3}; manually decraling array
        // we can also build array of objects
        //   nums[0] = 2;
        //   nums[1] = 4;
        //   nums[2] = 6;
        //   nums[3] = 8;


         
        int a[] = {2,4,8,6,8};
        // int b[] = {8,6,8,3,5};
        // int c[] = {9,3,6,8,3};

        int d[][]=  {
            {2,4,8,6,8},
            {8,6,8,3,5},
            {9,3,6,8,3}
        } ;           //array of 2 arrays
        //2d/multiple array of diferent column size is called jagged array
          
        for (int x = 0;x<3;x++)
        {
            for (int i = 0;i<4;i++)
            {
                System.out.print(" "+d[x][i]);
            }
            System.out.println();
        }

        //enhaced for loop
        for (int k : a ) //for 1 d array
        {
            System.out.println(k);
        }

        // enhacned for loop for multi dim array

        for (int x[] : d )
        {
            for(int y : x)
            {
                System.out.print(y);
            }
            System.out.println();
        }        
        
        }
    
}
